<tr>
<?php
include 'php/koneksi.php'
// Ambil ID dari parameter GET
$id = $_GET['id'];

// Ambil data pesan berdasarkan ID
$sql = $connect->query("SELECT * FROM konsli1 WHERE id='$id'");
$konsli1 = $sql->fetch_assoc();

// Jika data tidak ditemukan
if (!$konsli1) {
    echo "<div class='alert alert-danger' role='alert'>Data tidak ditemukan!</div>";
    exit;
}

// Proses update setelah form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $jenisjasa = $_POST['jenisjasa'];
    $deskripsi = $_POST['deskripsi'];

    $update_query = mysqli_query($connect, "UPDATE data SET nama='$nama', jenisjasa='$jenisjasa', deskripsi='$deskripsi', WHERE id='$id'");
    if ($update_query) {
        // Redirect dengan status edit success
        header("Location: Edit.php?id=$id&status_edit=success");
        exit();
    } else {
        // Redirect dengan status edit error
        header("Location: Edit.php?id=$id&status_edit=error");
        exit();
    }
}
?>
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>
        <div class="row g-0">
            <div class="col-md-2 d-flex flex-column flex-shrink-0 p-3 text-white bg-success" style="min-height: 100vh;">
                <a class="d-flex text-align-center text-white text-decoration-none" href="#" style="font-size: x-large;"><span class="fw-bold fs-3">BelajarBS</span></a>
                <hr>
                <ul class="nav nav-pills flex-column mb-auto" st>
                    <li class="nav-item">
                        <a href="3index.html" class="nav-link text-white fs-5"><i class="bi bi-house-door"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link text-white fs-5" ><i class="bi bi-journal"></i> Projects</a>
                    </li>
                    <li class="nav-item">
                        <a href="1index.html" class="nav-link text-white fs-5"><i class="bi bi-box-seam"></i> Service</a>
                    </li>
                </ul>
                <hr>
                <div class="dropdown">
                    <button class="btn dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-wrench"> </i>   Admin
                    </button>
                    <ul class="dropdown-menu dropdown-menu-light">
                        <li><a class="dropdown-item" href="#">Hengker</a></li>
                        <li><a class="dropdown-item" href="#">Spy</a></li>
                        <li><a class="dropdown-item" href="#">Bocorkan data pengguna</a></li>
                    </ul>
                </div>
            </div>
            
                <div class="col-md-10 text-dark d-flex overflow-auto" style="height:100vh;">
                    <div class="container-fluid">
                        <div class="row">
                        <form action="Edit.php?id=<?php echo $id; ?>" method="POST" class="col-md-11">
                  <div class="mb-3 ms-3">
                    <div class="card shadow">
                      <div class="card-header"><h4>Edit Customer Data</h4></div>
                      <div class="card-body">
                          <div class="form-group">
                            <label class="form-label" for="nama">Cust Name</label>
                            <input type="text" name="nama" id="nama" class="form-control" value="<?php echo $konsli1['nama']; ?>" required>
                          </div> 
                          <div class="form-group">
                            <label class="form-label" for="jenisjasa">Project Name</label>
                            <input type="text" name="jenisjasa" id="jenisjasa" class="form-control" value="<?php echo $konsli1['jenisjasa']; ?>" required>
                          </div> 
                          <div class="form-group"> 
                            <label class="form-label" for="deskripsi">Deskripsi</label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" required><?php echo $data['deskripsi']; ?></textarea>
                          </div>

                          <button type="submit" class="btn btn-success text-white mt-3">Update Pesan</button>
                      </div>
                    </div>
                  </div>
                </form>
                            </div>
                            <div class="col-md-5 ">
                            <div class="mt-3 me-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 class="fw-bold text-center pb-3">
                                        Add Project
                                    </h1>
                                    </div>
                                    <div class="card-body">
                                        <form action="php/create.php" method="POST">
                                            <label class="form-label" for="nama">Customer Name</label>
                                            <input type="text" class="form-control" name="nama" id="nama" aria-label="Sizing example input" required>
                                            <label class="form-label" for="">Project Name</label>
                                            <input type="text" class="form-control" name="jenisjasa" id="jenisjasa" aria-label="Sizing example input" required>
                                            <label class="form-label" for="">Description</label>
                                            <textarea class="form-control" name="deskripsi" id="deskripsi"></textarea>
                                            <label class="form-label" for="">Project Status</label>
                                            <div class="form-check" required>
                                                <label class="form-label" for="">Ongoing</label>
                                                <input name="status" class="form-check-input" type="radio">
                                                
                                            </div>
                                            <div class="form-check" required>
                                                <label class="form-check-label" for="">Finished</label>
                                                <input name="status" class="form-check-input" type="radio">
                                            </div>
                                            <button type="submit" class="btn btn-primary text-white mt-3" id="submit" name="submit">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="modal fade" aria-hidden="true"></div>

                </div>
            </div>
        </div>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    </body>
    </html>