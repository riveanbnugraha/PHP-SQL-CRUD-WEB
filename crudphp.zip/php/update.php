<?php
include 'koneksi.php';
$id = $_POST['id'];
$nama = $_POST['nama'];
$jenisjasa = $_POST['jenisjasa'];
$deskripsi = $_POST['deskripsi'];
$query = mysqli_query ($connect, "UPDATE konsli1 SET nama='$nama', jenisjasa='$jenisjasa', deskripsi='$deskripsi' WHERE id='$id'");
if ($query) {
    echo "<div class='alert alert success' style='text-align:center;''>Data berhasil diubah</div>";
    header("Refresh: 1; url=../index.php"); 
} else {
    echo "<div class='alert alert-danger'>Upload failed</div>";
    header("Refresh: 1; url=../index.php"); 
}
?>