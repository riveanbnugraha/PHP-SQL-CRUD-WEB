<?php
include "koneksi.php";
$nama = $_POST["nama"];
$jenisjasa = $_POST["jenisjasa"];
$deskripsi = $_POST["deskripsi"];
$query = mysqli_query($connect, "INSERT INTO konsli1 (nama,jenisjasa,deskripsi) VALUES ('$nama', '$jenisjasa', '$deskripsi')");
if ($query) {
    echo "<div class='alert alert-succes' style='text-align:center;'><h1>Data berhasil disimpan!</h1></div>";
    header("Refresh: 1; url=../index.php");
}else{
    echo "<div class='alert alert-danger>Upload gagal</div>";
}
?>