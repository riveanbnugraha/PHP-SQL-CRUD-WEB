<?php
include 'koneksi.php';
$id = $_GET['id'];
$sql = $connect -> query("SELECT * from konsli1 where id ='$id'");
$konsli1 = $sql -> fetch_assoc();
$query = $connect -> query("DELETE from konsli1 where id ='$id'");

if ($query) {
    header("Refresh: 1; url=../index.php");
} else {
    header("Refresh: 1; url=../index.php");
}
?>